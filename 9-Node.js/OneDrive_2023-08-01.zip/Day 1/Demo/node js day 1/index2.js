function printMsg(msg){

      console.log(msg);
}

var y=50

var emp={name:"ali",age:27}


// module.exports =printMsg

module.exports={printMsg,emp}

// module.exports=y
